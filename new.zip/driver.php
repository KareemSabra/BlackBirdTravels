<?php

require_once "config.php";
//require_once "session.php";
session_start();
if (!isset($_SESSION["userid"]) || $_SESSION["userid"] !== true) {
    header("location: index.php");
    exit;
}


$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {


    $target = trim($_POST['pin']);




    // validate if email is empty
    if (empty($target)) {
        $error .= '<p class="error">Please enter a pin.</p>';
    }

    if (empty($error)) {
      $query = mysqli_query($con, "SELECT * FROM `Customers` WHERE Pin = $target");

    if(!empty($query)){
   

$row = mysqli_fetch_assoc($query);
  }


}

// Close connection

mysqli_close($con);
/*header("location: datashowing.php");

    exit;
*/
}
?>






<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Black Bird Travels</title>

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/managerstyles.css">
</head>
    <body>
      <header>
         <nav id="header-nav" class="navbar navbar-default">
              <div class="container">
                  <div class="navbar-header">

                      <div class="navbar-brand">
                          <a href="manager.php"><h1>Black Bird Travel</h1></a>

                      </div>

                      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapsable-nav" aria-expanded="false">
                          <span class="sr-only">Toggle navigation</span>
                          <span class="icon-bar"></span>
                          <span class="icon-bar"></span>
                          <span class="icon-bar"></span>
                      </button>
                  </div>

                  <div id="collapsable-nav" class="collapse navbar-collapse">
                      <ul id="nav-list" class="nav navbar-nav navbar-right">
                          <li>
                              <a  href="logout.php" class="tablinks">
                              Logout
                                 </a>
                          </li>
                      </ul><!-- #nav-list -->
                  </div><!-- .collapse .navbar-collapse -->
              </div><!-- .container -->
          </nav><!-- #header-nav -->
           <br>
      <br>

          <div class="container">
          <div class="row">
              <div class="col-md-offset-4 col-md-4 col-sm-offset-3 col-sm-6 col-xs-offset-3 col-xs-6 width-100">
                  <form action="" method="post">
                      <div class="loginpage">
                          <input class="form-control placeholder-fix" type="text" placeholder="Please Enter a Pin" name="pin" required="">
                      </div>
                      <div class="action-button">
                          <button class="btn-block" type="submit" value="submit" name="submit">Enter</button>
                      </div>
                  </form>
              </div>
          </div>
      </div>


    <div class="container" style="padding: 5%;" id="boardingview">
        <div class="row" >
            <div class="col-md-offset-4 col-md-4 col-sm-offset-3 col-sm-6 col-xs-offset-3 col-xs-6 width-100" style="background-color: White">
        <img style="width:150px ;background-color: White; height:150px;" src="<?php echo $row["ImageURL"]; ?>"/>
        <div style=" background-color: White; color: black;">
            <span>Name:</span><span><?php echo $row["Name"]; ?></span>
        </div>
        <div style=" background-color: White; color: black;">
            <span>University:</span><span><?php echo $row["University"]; ?></span>
        </div>
        <div style=" background-color: White; color: black;">
            <span>Phone number:</span><span><?php echo $row["MobileNumber"]; ?></span>
        </div>
        <div style=" background-color: White; color: black;">
            <span>Parent Number</span><span><?php echo $row["ParentNumber"]; ?></span>
        </div>
        </div>
        </div>





    </div>
          <script src="js/jquery-2.1.4.min.js"></script>
          <script src="js/bootstrap.min.js"></script>
          <script src="js/managerscript.js"></script>
    </body>
    </html>
